export const submitNote = (noteData) => {
	const {importance, text} = noteData;
	return {
		type: 'NOTE_CREATE',
		payload: {
			id: new Date().getTime(),
			content: text,
			important: importance
		}
	}
}

export const handleDraftText = (text) => {
	return {
		type: 'DRAFT_TEXT',
		payload: text
	}
}

export const draftClean = () => {
	return {
		type: 'DRAFT_CLEAN',
		payload: null
	}	
}


export const handleDraftImportance = (important) => {
	return {
		type: 'DRAFT_IMPORTANCE',
		payload: important
	}
}