let initialState = {
	draft: {
		importance: false,
		text: ''
	},
	notes: [
		{
			id: 1,
			content: 'Test Init Note',
			important: true
		},
	]
}

const noteReducer = (state = initialState, action) => {
	console.log('state noteReducer :>> ', state);
	console.log('action noteReducer :>> ', action);
	const {payload} = action;
	const {importance, text} = state.draft;
	
	switch (action.type) {
		case 'DRAFT_CLEAN':
			return {
				draft: {
					importance: false,
					text: ''
				},
				notes: [...state.notes]
			}
		case 'DRAFT_TEXT':
			return  {
				draft: {
					importance,
					text: payload
				},
				notes: [...state.notes]
			}
		case 'DRAFT_IMPORTANCE':
			return {
				draft: {
					importance: payload,
					text 
				},
				notes: [...state.notes]
			}
		case 'NOTE_CREATE':
			return {
				draft: state.draft,
				notes: [
					...state.notes,
					{
						id: payload.id,
						content: payload.content,
						important: payload.important
					}
				]
			}
		default:
			return state
	}
}

export default noteReducer;