import React from 'react';
import { useSelector } from 'react-redux';
import NewNote from './components/NewNote';
import Notes from './components/Notes';



const App = (props) => {
	console.log('props :>> ', props);
	const storeNow = useSelector(state => state);	
	return (
		<>
			<div>
				<h1>{props.title}</h1>
			</div>
			<div>
				<h3>Store:</h3>
				<pre>
					{`{draft: '${JSON.stringify(storeNow.draft)}'}`}
				</pre>
			</div>
			<NewNote />
			<Notes />
		</>
	);
}

export default App;
