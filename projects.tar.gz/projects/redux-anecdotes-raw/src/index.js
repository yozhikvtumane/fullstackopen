import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import store from './store/storeConfig'
import { Provider } from 'react-redux'

const renderApp = () => { 
		ReactDOM.render(
		<Provider store={store}>
			<App title={'Notes App'}/>
		</Provider>,
		document.getElementById('root'));
}

renderApp()
store.subscribe(renderApp)




