import React from 'react';
import { useSelector } from 'react-redux';


const Notes = () => {
	const storeNow = useSelector(state => state);
	
	return(
		<>
			<h3>Notes:</h3>
			<ul>
				{storeNow.notes.map((note, index) => {
					if (note.id === 1) return null
					return (
						<li key={index}>
							<h3>Note id {note.id}</h3>
							{note.content}
							<input
								type="checkbox"
								disabled
								checked={note.important}
								/>
						</li>
					)
				})}
			</ul>
		</>
	)
}

export default Notes;