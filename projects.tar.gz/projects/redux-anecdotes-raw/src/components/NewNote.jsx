import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import * as notesActions from '../actions/notesActions';

const NewNote = () => {
	const dispatch = useDispatch();
	const storeNow = useSelector(state => state);
	
	const handleNoteDraftText = (e) => {
		console.log('e :>> ', e.target);
		console.dir(e.target);
		dispatch(notesActions.handleDraftText(e.target.value));
	}
	const handleImportanceChange = (e) => dispatch(notesActions.handleDraftImportance(e.target.checked));
	const submitNote = (e) => {
		e.preventDefault();
		dispatch(notesActions.submitNote(storeNow.draft))
		dispatch(notesActions.draftClean())
	}
	
	return (
		<form onSubmit={submitNote}>
			<h3>New note:</h3>
			<p>
				<input 
					type="text"
					name="draftText"
					value={storeNow.draft.text}
					onChange={handleNoteDraftText}
					/>
				<input
					type="checkbox"
					name="draftImportance"
					checked={storeNow.draft.importance}
					onChange={handleImportanceChange}/>
				<input type="submit"/>
			</p>
		</form>
	)
}

export default NewNote;