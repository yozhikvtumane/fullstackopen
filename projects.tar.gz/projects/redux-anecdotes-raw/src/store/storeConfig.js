import { createStore } from 'redux';
import noteReducer from '../reducers/noteReducer'


const store = createStore(noteReducer);

store.subscribe(() => {
	const storeNow = store.getState();
	console.log('storeNow from storeConfig :>> ', storeNow);
});


export default store;
