import React from 'react'
import { useSelector, useDispatch } from 'react-redux'
import * as anecdoteActions from './actions/anecdoteActions';

const App = () => {
	const anecdotes = useSelector(state => state)
	const dispatch = useDispatch()

	const vote = (id) => {
		dispatch(anecdoteActions.vote(id));
		console.log('vote', id)
	}
	
	const createNew = (e) => {
		e.preventDefault();
		console.log('e.target :>> ', e.target);
		console.log('e.target.newAnecdote :>> ', e.target.newAnecdote.value);
		console.dir(e.target);
		dispatch(anecdoteActions.createNew(e.target.newAnecdote.value));
		e.target.newAnecdote.value = '';
	}
	
	return (
	<div>
		<h2>Anecdotes</h2>
		{anecdotes.map(anecdote =>
		<div key={anecdote.id}>
			<div>
			{anecdote.content}
			</div>
			<div>
			has {anecdote.votes}
			<button onClick={() => vote(anecdote.id)}>vote</button>
			</div>
		</div>
		)}
		<h2>create new</h2>
			<form onSubmit={createNew}>
				<div>
					<input type="text" name="newAnecdote" />
				</div>
				<input type="submit" value="Create new" />
			</form>
	</div>
	)
}

export default App