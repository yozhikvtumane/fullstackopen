export const createNew = (anecdoteData) => {
	return {
		type: 'NEW_ANECDOTE',
		payload: {
			content: anecdoteData
		}
	}
}

export const vote = (anecdoteId) => {
	return {
		type: 'VOTE',
		payload: anecdoteId
	}
}